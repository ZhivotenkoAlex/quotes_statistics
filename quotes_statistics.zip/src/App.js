import Quotes from "./components/Quotes";
import Ping from "./components/ping/Ping";

function App() {
  return (
    <>
      <Quotes />
      <Ping />
    </>
  );
}

export default App;
